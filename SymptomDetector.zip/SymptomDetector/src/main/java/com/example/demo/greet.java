package com.example.demo;
public class greet {

	
	private final String content;

	public greet( String content) {
		
		this.content = content;
	}


	public String getContent() {
		return content;
	}
}